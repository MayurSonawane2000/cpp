
/*


#include <iostream>
#include <cstring>
using namespace std;

class Animal {
protected:
    char name[50];
    int age;

public:
    Animal(const char* n, int a) : age(a) {
        strncpy(name, n, sizeof(name) - 1);
        name[sizeof(name) - 1] = '\0';
    }

    virtual ~Animal() {}

    virtual void talk() const = 0;  // Pure virtual function

    const char* getName() const {
        return name;
    }

    int getAge() const {
        return age;
    }
};

class Dog : public Animal {
public:
    Dog(const char* n, int a) : Animal(n, a) {}

    void talk() const override {
        cout << "Woof! Woof!" << endl;
    }
};

class Cat : public Animal {
public:
    Cat(const char* n, int a) : Animal(n, a) {}

    void talk() const override {
        cout << "Meow! Meow!" << endl;
    }

    bool operator==(const Cat& other) const {
        return strcmp(name, other.name) == 0;
    }
};

int main() {
    // Animal *animal = new Animal();  // This line would give compile-time error

    // My Dog name is Boss & age is 15 months
    Animal *dogPtr = new Dog("Boss", 15);
    dogPtr->talk();  // Every animal has unique way of sound
    delete dogPtr;

    // My cat name is Puppy & she is 3 month old and it is-a Animal
    Cat c1("Puppy", 3);
    Cat c2("Sweety", 4);

    // Use strcmp function to compare names of 2 Cat
    if (c1 == c2)
        cout << "Both are same!" << endl;
    else
        cout << "Both are different!" << endl;

    c1.talk();

    return 0;
}


*/


#include <iostream>
#include <cmath>
using namespace std;

// Abstract base class for Shape
class Shape {
public:
    virtual ~Shape() {}

    virtual double getArea() const = 0; // Pure virtual function
};

// Triangle class derived from Shape
class Triangle : public Shape {
private:
    double width;
    double height;

public:
    Triangle(double w, double h) : width(w), height(h) {}

    double getArea() const override {
        return (width * height) / 2;
    }
};

// Circle class derived from Shape
class Circle : public Shape {
private:
    double x;
    double y;
    double radius;

public:
    Circle(double x, double y, double r) : x(x), y(y), radius(r) {}

    double getArea() const override {
        return 3.14 * radius * radius;
    }

    bool operator==(const Circle& other) const {
        return fabs(this->getArea() - other.getArea()) < 1e-9;
    }
};

// Rectangle class derived from Shape
class Rectangle : public Shape {
private:
    double width;
    double height;

public:
    Rectangle(double w, double h) : width(w), height(h) {}

    double getArea() const override {
        return width * height;
    }

    bool operator==(const Rectangle& other) const {
        return fabs(this->getArea() - other.getArea()) < 1e-9;
    }
};

int main() {
    // Shape *shape = new Shape();  // This line would give compile-time error

    // My Triangle's width is 10 & height is 3
    Shape *triangleShape = new Triangle(10, 3);

    // Triangle's area formula is (width * height)/2
    cout << "Triangle's area: " << triangleShape->getArea() << endl;

    delete triangleShape;

    // My Circle's centre is at 2,2 (x,y) and radius of 3 and it is-a Shape
    Circle c1(2, 2, 3);
    Circle c2(3, 3, 8);

    // Please check both circles areas to verify whether they are equal or not
    // Circle's area formula is (3.14 * radius * radius)
    if (c1 == c2)
        cout << "Both circles are of same area" << endl;
    else
        cout << "Both circles are of different area" << endl;

    // My Rectangle's width is 4 & height is 5
    Rectangle r1(4, 5);
    Rectangle r2(4, 5);

    // Please check both rectangles areas to verify whether they are equal or not
    // Rectangle's area formula is (width * height)
    if (r1 == r2)
        cout << "Both rectangles are of same area" << endl;
    else
        cout << "Both rectangles are of different area" << endl;

    return 0;
}
