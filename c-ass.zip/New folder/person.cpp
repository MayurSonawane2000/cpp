#include <iostream>
#include <cstring>
using namespace std;

// Abstract base class for Person
class Person {
protected:
    char name[50];

public:
    Person(const char* n) {
        strncpy(name, n, sizeof(name) - 1);
        name[sizeof(name) - 1] = '\0';
    }

    virtual ~Person() {}

    virtual const char* getName() const = 0; // Pure virtual function
};

// Student class derived from Person
class Student : public Person {
public:
    Student(const char* n) : Person(n) {}

    const char* getName() const override {
        return name;
    }
};

// Teacher class derived from Person
class Teacher : public Person {
public:
    Teacher(const char* n) : Person(n) {}

    const char* getName() const override {
        return name;
    }
};

int main() {
    // Person *person = new Person();  // This line would give compile-time error

    // Creating a Student
    Person* student = new Student("John Doe");
    cout << "Student name: " << student->getName() << endl;
    delete student;

    // Creating a Teacher
    Person* teacher = new Teacher("Jane Smith");
    cout << "Teacher name: " << teacher->getName() << endl;
    delete teacher;

    return 0;
}
