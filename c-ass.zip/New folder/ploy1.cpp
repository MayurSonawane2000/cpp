#include <iostream>
#include <cstring>
using namespace std;

class Animal {
protected:
    char name[50];
    int age;

public:
    Animal(const char* n, int a) : age(a) {
        strncpy(name, n, sizeof(name) - 1);
        name[sizeof(name) - 1] = '\0';
    }

    virtual ~Animal() {}

    virtual void talk() const = 0;  // Pure virtual function

    const char* getName() const {
        return name;
    }

    int getAge() const {
        return age;
    }
};

class Dog : public Animal {
public:
    Dog(const char* n, int a) : Animal(n, a) {}

    void talk() const override {
        cout << "Woof! Woof!" << endl;
    }
};

class Cat : public Animal {
public:
    Cat(const char* n, int a) : Animal(n, a) {}

    void talk() const override {
        cout << "Meow! Meow!" << endl;
    }

    bool operator==(const Cat& other) const {
        return strcmp(name, other.name) == 0;
    }
};

int main() {
    // Animal *animal = new Animal();  // This line would give compile-time error

    // My Dog name is Boss & age is 15 months
    Animal *dogPtr = new Dog("Boss", 15);
    dogPtr->talk();  // Every animal has unique way of sound
    delete dogPtr;

    // My cat name is Puppy & she is 3 month old and it is-a Animal
    Cat c1("Puppy", 3);
    Cat c2("Sweety", 4);

    // Use strcmp function to compare names of 2 Cat
    if (c1 == c2)
        cout << "Both are same!" << endl;
    else
        cout << "Both are different!" << endl;

    c1.talk();

    return 0;
}
