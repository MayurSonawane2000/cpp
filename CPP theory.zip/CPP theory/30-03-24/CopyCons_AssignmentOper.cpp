#include<iostream>
using namespace std;

class myInt{
   int *ptr;

   public :
       myInt()
       {
           ptr = new int;
           *ptr = 0;
           cout<<"\n Default constructor is called..";
       }
       myInt(int n)
       {
           ptr = new int;
           *ptr = n;
           cout<<"\n Parameterzied constructor is called..";
       }
       ~myInt()
       {
           cout<<"\n Destructor is called..";
           delete ptr;
       }
        void display()
        {
            cout<<"\n Value is :"<<*ptr;
        }

        int getValue()
        {
            return *ptr;
        }
        void setValue(int a)
        {
            *ptr = a;
        }

        myInt operator +(myInt o)
        {
            myInt temp;
            temp.setValue(*ptr + o.getValue());
            return temp;
        }

        myInt operator -(myInt o)
        {
            myInt temp;
            temp.setValue(*ptr - o.getValue());
            return temp;
        }

        myInt(const myInt &r)
        {
            ptr = new int;
            *ptr = *r.ptr;
            cout<<"\n Copy constructor is called..";
        }

        void operator =(const myInt &r)
        {
            delete ptr;
            ptr = new int;
            *ptr = *r.ptr;
        }


};




int main()
{

    myInt obj1(14);
    myInt obj2(10);
    myInt obj3;

    obj3 =obj1 + obj2; // ==>  obj1.operator+(obj2)


    //obj3 = tempObj;   //==> obj3.operator = (tempobj)
    obj3.display();
    return 0;
}
