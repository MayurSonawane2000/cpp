#include<iostream>
using namespace std;
int main()
{
 int i;
 const char *month[]= {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
 enum months {jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec};

 enum months m;

 cout<<"\n Enter month number..";
 cin>>i;


switch(i)
{
    case jan : cout<<"Jan"; break;
    case feb:  cout<<"Feb"; break;
    default: cout<<"Default";
}

cout<<"\n\n"<<month[jan];
cout<<"\n\n";

//use enum in loop
 for(i=jan;i<=dec;i++)    
    cout<<"\n "<<month[i];

 return 0;
 }

 
