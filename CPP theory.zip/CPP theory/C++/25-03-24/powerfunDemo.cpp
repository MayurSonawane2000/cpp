#include<iostream>
using namespace std;

int power(int n, int m)   //2^5 ==>  2*2*2*2*2
{
    int i, p = 1;

    for(i=1;i<=m;i++)
        p = p * n;

    return p;
}

int main()
{
    int i;
    for(i=1; i<=5 ; i++)
        fun();

    return 0;
}
