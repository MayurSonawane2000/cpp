#include<iostream>
using namespace std;

int main()
{
    int num, rev_num = 0, rem;
    cout<<"\n Enter a number : ";
    cin>>num;
    while(num > 0)
    {
        rem = num % 10;
        if((rev_num > (INT_MAX/10))|| (rev_num < (INT_MIN / 10)))
            return 0;

        rev_num = rev_num * 10 + rem;
        num = num / 10;
    }
    cout<<"\n Reverse number = "<<rev_num;
    return 0;
}
