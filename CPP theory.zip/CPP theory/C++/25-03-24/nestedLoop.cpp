#include<iostream>
using namespace std;

int main()
{
    int n, i,j;

    for(i=1; i<=4 ; i++)   // i = 5
    {
        cout<<"\n Enter a number :";
        cin>>n;
        cout<<"\n";
        for(j=1 ; j<=10 ; j++)   // j = 1
        {
            cout<<"  "<<n*j;
        }
    }

    return 0;
}
