#include<iostream>
using namespace std;

int main()
{
    int number= 6;
    const int i=10;

    cout<<"\n i = "<<i;
    //i = 60;
    constexpr int num = 34 * i;

    cout<<"\n num = "<<num;
    return 0;
}
