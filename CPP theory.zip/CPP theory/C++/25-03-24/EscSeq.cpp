#include<iostream>
using namespace std;

int main()
{
    cout<<"\a Good Morn\ring!";
    cout<<"\n Hello\\world";

    return 0;

}



