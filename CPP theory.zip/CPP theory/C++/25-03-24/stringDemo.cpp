#include<iostream>
using namespace std;

int main()
{
    string str;
    cout<<"\n Enter string: ";
    cin>>str;

    cout<<"\n Entered string is : "<<str;

    cout<<"\n"<<str.length();

    cout<<"\n Changed string is : "<<str;

    for(int i=0;str[i]!='\0';i++)
        cout<<"\n"<<str[i];

    return 0;


}
