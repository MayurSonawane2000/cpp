#include<iostream>
using namespace std;

void fun()
{
    static int i = 4;
    i++;
    cout<<"\n i = "<<i;
    return;
}

int main()
{
    int i;
    for(i=1; i<=5 ; i++)
        fun();

    return 0;
}
