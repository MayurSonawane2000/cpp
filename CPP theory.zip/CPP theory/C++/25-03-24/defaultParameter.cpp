/*  Default parameter is value given to parameter in formal parameter list
If a function has default parameter, the caller can skip passing the value
for that parameter in actual parameter list.

*/
#include<iostream>
using namespace std;

int g_i;


int sum(int x, int y = 4)   //  int y = m
{
    return x + y;

}

int main()
{
    int n = 10,m = 20;
    cout<<"\n Sum = "<<sum(n,m);

    return 0;
}

