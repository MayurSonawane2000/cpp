/*
Program		: To demonstate the operator overloading of special operators [], 
				() and ->
Program	By	: Anil Donwade
Date		: 24-04-2024
*/
 
#include<iostream>
using namespace std;

class Array{
	int array[10];
public:
	Array(){			//default constructor
	
	}
	
	Array(int array[], int size){		//parameterized constructor
		//loop to populate an array
		for(int i=0; i<size; i++)
			this->array[i]=array[i];
	}

	int& operator[](int index){
		cout << "operator[] called .....\n";
		if(index <0 || index >9){
			cout << "Array index invalid " << index;
			exit(1);
		}
		return array[index];
	}
	
//	void display(){
//		cout << meter << "m "<<  centimeter << "cm"<<"\n";
//	}
	
};

int main(){
	int a[]={1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	Array array(a, 10);
	//cout << array[14] << "\n";
	
	a[17]=80;
//	cout << a[17]<< "\n";

	cout << array[4] << "\n";
	array[4]=40;
	cout << array[4] << "\n";
}

