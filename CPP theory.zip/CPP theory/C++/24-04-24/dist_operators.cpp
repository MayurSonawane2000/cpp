/*
Program		: To demonstate the operator overloading of binary operator +
Program	By	: Anil Donwade
Date		: 24-04-2024

Operators, which can not be overloaded are as follows:
	. 	member access operator
	::	scope resolution operator
	?:	ternary operator
	.*	member de-referencing operator
*/
 
#include<iostream>
using namespace std;

//class representing distance entity
class Distance{
	int meter;
	int centimeter;
public:
	Distance(){								//default constructor
		meter=0; centimeter=0;
	}
	
	Distance(int meter, int centimeter){	//parameterized constructor
		this->meter=meter; 
		this->centimeter=centimeter;
	}
	/* 4 20	2 10 => 6 30 */
	//operator function to add two distance objects and it return the 
	//resulting object  after addition
	Distance operator+(Distance d){
		Distance temp;				//resulting object
		temp.centimeter = centimeter + d.centimeter; //add centimeters
		if(temp.centimeter >= 100){					 //check for meter correction
			temp.centimeter -= 100;					 //reduce centimeter
			temp.meter++;							 //increment meter by 1
		}
		temp.meter += meter + d.meter;				 //add meters
		return temp;				//retutn the resulting distance
	}
	// 5 60 => 6 60
//	Distance operator++(){		//pre-increment  operator function
//		++this->meter;
//		return *this;
//	}
//	
	Distance operator++(int x){	//post-increment  operator function
		this->meter++;
		return *this;
	}
	
	Distance operator=(Distance d){	//assignnment operator function
		this->meter = d.meter;
		this->centimeter = d.centimeter;
		return *this;
	}
	
	Distance operator+=(Distance d){	//compound assignnment  operator function
		this->meter += d.meter;
		this->centimeter += d.centimeter;
			if(this->centimeter >= 100){		//check for meter correction
			this->centimeter -= 100;			//reduce centimeter
			this->meter++;					//increment meter by 1
		}
		return *this;
	}
	
	void display(){
		cout << meter << "m "<<  centimeter << "cm"<<"\n";
	}
	
	//friend functions, as non-member operator functions
	friend Distance& operator++(Distance d);
	friend Distance& operator+(Distance d, int m);
	friend Distance& operator+(int m, Distance d);
};

//main() function
int main(){
	Distance d1(4, 20), d2(2, 10), d;
	d = d1 + d2;						// d = d1.operator+(d2);
	d.display();
	
	cout << "Now with friend function ....\t";
	d = ++d1;
	d.display();
	
	d = d2++;
	d.display();
	
	Distance d3 = d;
	d3.display();
	
	d += d1;
	d.display();
	
	cout << "Now with friend function ....\t";
	d = d1 + 10;
	d.display();
	
	d = 10 + d1;
	d.display();
}

//non-member operator function,
//for pre-increment
Distance& operator++(Distance d){
	d.meter++;
	return d;
}

//for adding constant meter to distance
Distance& operator+(Distance d, int m){
	d.meter+=m;
	return d;
}

//for adding constant meter to distance, in different way
Distance& operator+(int m, Distance d){
	d.meter+=m;
	return d;
}
