
#ifndef POINT__H_
#define POINT__H_

class Point
{
    int x,y;
public:
    Point();
    Point(int,int);
    void display();
};

#endif // POINT__H_
