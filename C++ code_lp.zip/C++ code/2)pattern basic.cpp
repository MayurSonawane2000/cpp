#include<iostream>
using namespace std;

int main()
{
    int i, j,k;







/*
      for(int i=5;i>=1;i--)
    {
        cout<<"1";
        for(int j=1;j<=i;j++)
        //{
            cout<<" *";
            cout<<"2";
        //}
            cout<<"\n";
    }



      for(int i=1;i<=5;i++)
    {
        cout<<"1";
        for(int j=1;j<=i;j++)
        //{
            cout<<" *";
            cout<<"2";
        //}
            cout<<"\n";
    }

*/




 for(int i=1;i<=5;i++)
    {

        for(int j=i;j<=5;j++)
        {
            cout<<" *";
        }
        for (int k=2;k<=i*2;k++)
        {
            cout<<"  ";
        }
        for (int l=i;l<=5;l++)
        {
            cout<<" *";
        }


        cout<<"\n";
    }





for(int i=1;i<=5;i++)
    {

        for(int j=1;j<=i;j++)
        {
           cout<<" *";
        }
        for (int k=1;k<=5;k++)
        {
            cout<<" 0 ";
        }
       // for (int l=1;l<=5;l++)
        //{
          //  cout<<" *";
        //}
      for(j=((2*i)-2);j>=1 ; j--)
      {
          cout<<" *";
      }



cout<<"\n";

       }
}





