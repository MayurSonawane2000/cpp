/*
#include<iostream>
using namespace std;

int main(){
    cout<<"---start---\n";
    int x=100,y;

    y=1;
    try{
        cout<<" enter in try block....\n";
        if(y==0)throw 10;
        cout <<"x=" <<x << "\n";



    }catch (int e){
        cout<<"Now in catch block e=" << e << "\n";

    }
    cout <<"===end---\n";
    return 0;

}




#include<iostream>
using namespace std;

void function(int n){



    int x=100,y;

    y=n;
    try{
        cout<<" enter in try block....\n";
        if(y==0)throw 10;
        cout <<"x=" <<x << "\n";



    }catch (int e){
        cout<<"Now in catch block e=" << e << "\n";

    }


}

int main(){
    cout<<"---start---\n";
    function(0);
    cout <<"===end---\n";
    return 0;
}


*/


#include<iostream>
using namespace std;

void function1(int n){



    int x=100,y;
    int arr[]={100,200,300};

    y=n;
    try{
        cout<<" enter in try block....\n";
        if(y==0)throw 10;
        cout <<"value" <<x*n << "\n";


        if(n>3) throw 1.0*n;
            cout << arr[n]<< "\n";



    }catch (int e){
        cout<<"Now in catch block e:=" << e << "\n";
    }

    }






int main(){
    cout<<"---start---\n";
    try{

        function1(1);

    }catch(...){

        cout<<"Now you are safe .crash is avoided.\n";

    }

    cout <<"===end---\n";
    return 0;
}


