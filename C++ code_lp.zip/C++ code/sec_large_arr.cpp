#include<iostream>
using namespace std;
int main()
{

    int arr[10]={45,65,85,78,95,5,6,78,45,89};
    int largest =arr[0],sec_largest;
    for (int i=1;i<10;i++)
    {
        if arr[i]>largest()
        {
            sec_largest=largest;
            largest=arr[i];
        }
        else if (arr[i]>sec_largest)
            sec_largest=arr[i]
    }

}
