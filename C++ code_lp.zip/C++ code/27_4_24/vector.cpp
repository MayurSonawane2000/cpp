#include<iostream>
#include<set>
using namespace std;

int main(){
    set<int> v={1,2,3,4,5,6,7,8,9};
    v.insert(10);
    v.insert(20);
    v.insert(30);

   set<int>::iterator itr;

   cout<<"using iterator in vector";
   for(itr=v.begin();itr!=v.end();itr++)
    cout<<*itr<<endl;




    cout<<"Using for loop";
    for (int x:v)
        cout<<x<<endl;


}
