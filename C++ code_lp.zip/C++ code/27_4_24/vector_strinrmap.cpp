/*
    To demostrate create map using for int and string create a list for add using  and delete librariy
*/

#include<iostream>
#include<map>
using namespace std;

int main()
{

    map<int,string> m;
    m.insert(pair<int,string>(1,"mayur"));
    m.insert(pair<int,string>(2,"harish"));
    m.insert(pair<int,string>(3,"pankaj"));
    m.insert(pair<int,string>(4,"yatharth"));



    cout<<"original map list:-\n";
    map<int,string>::iterator itr;

    for(auto itr=m.begin();itr!=m.end();itr++)
        cout<<itr->first<<" "<<itr->second<<endl;

        //add element
        m.insert(pair<int,string>(5,"harihar"));

        //delete element
        m.erase(3);





        cout<<"Modified map :-\n";
        for(auto itr=m.begin();itr!=m.end();itr++)
        cout<<itr->first<<" "<<itr->second<<endl;


}
