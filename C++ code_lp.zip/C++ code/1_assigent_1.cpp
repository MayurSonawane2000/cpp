#include<iostream>
using namespace std;

char s1[10];
char s2[10];




    void display(char s[])
    {
        cout<<s<<" ";
    }
    void display(char s[],char s1[])
    {
        cout<<s<<"  "<<s1;
    }


int main()
{
    char s[10]="Prudent";
    char s1[10]="Academy";

    display(s);
    display (s,s1);

    return 0;
}
