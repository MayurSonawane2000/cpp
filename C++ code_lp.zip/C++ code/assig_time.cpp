#include<iostream>
using namespace std;


class time
 {
    int HH, MM, SS;

public:
    void set_hour(int H)
     {
        HH = H;
    }
    void set_min(int M)
    {
        MM = M;
    }
    void set_sec(int S)
    {
        SS = S;
    }
    void set_time(int H, int M, int S)
     {
        HH = H; MM = M; SS = S;



        cout << "\n" << HH << "-" << MM << "-" << SS;



        if (SS==59)
        {
            if (MM==59)
            {
                if (HH==12)
                {
                    HH=1;
                }
                else
                    HH=HH+1;
                    MM=0;

            }
            else
                MM=MM+1;
                SS=0;

        }
        else
            SS=SS+1;

    }

    void display()
    {
        cout << "\n" << HH << "-" << MM << "-" << SS;
    }
};


int main()
 {
    time obj1 ,obj2;

    obj1.set_time(2, 59, 55);
    obj1.display();










}
