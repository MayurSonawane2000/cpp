#include<iostream>.h>
#include<cstring>
using namespace std;

class palindrome
{
    char str[100];

public:
    palindrome(){
        strcpy(str, "NITIN");

        }
    palindrome(const char *str){
        strcpy(this->str,str);

    }
    bool palindrome(){
    int len = strlen(str);
    char *p1=(str + 0);
    char *p2=(str + len-1);

    while(p1 <p2){
        if(*p1==*p2){
            p1++;
            p2--;
        }else
        return false;
    }

    }



};
