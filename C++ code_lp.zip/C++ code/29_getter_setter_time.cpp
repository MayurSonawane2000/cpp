
/*
Add getters and setters in time and call these methods from main()
*/

/*
#include<iostream>
using namespace std;


class time
{
    int hh, mm, ss;



public:
    time()
    {
        hh=11;
        mm=25;
        ss=59;
    }

int get_hour()
{
    return hh;
}
void set_hour(int h)
{
    hh=h;
}

int get_min()
{
    return mm;
}
void set_min(int m)
{
    mm=m;
}

int get_sec()
{
    return ss;
}
void set_sec(int s)
{
    ss=s;
}


void display()
{
    cout<<"\n"<<hh<<"-"<<mm<<"-"<<ss;
}
~time()
{
    cout<<"\n Destructor is callesd....";
}

};


int main()
{
    time obj1;
    obj1.display();

    return 0;
}

*/
/*------------------------------------------------------------------------------------*/


/*
Add getters and setters in point and call these methods from main()
*/



#include<iostream>
using namespace std;


class point

{
    int a,b,c;
public:
    point ()
    {
        a=12;
        b=34;
        c=45;
    }

int  get_avalue()
{
    return a;
}
void set_avalue(int x)
{
    a=x;
}

int get_bvalue()
{
    return b;
}
void set_bvalue(int y)
{
    b=y;
}

int get_cvalue()
{
    return c;
}
void set_cvalue(int z)
{
    c=z;
}

void display()
{
    cout<<"\n avalue:-"<<a<<"\n bvalue:-"<<b<<"\n cvalue:-"<<c;
}


};


int main()
{
    point obj1;
    obj1.display();



    return 0;
}









