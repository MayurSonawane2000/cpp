#include<iostream>
#include<vector>
using namespace std;


int main(){
    //create an integer vector
    vector<int> intv;

    intv.push_back(100);
    intv.push_back(200);
    intv.push_back(300);
    intv.push_back(400);
    intv.push_back(500);
    intv.push_back(600);



    vector<int>::iterator itr =intv.begin();
    intv.insert(itr,102);

    cout << "Now displaying the vector elements...\n";

    for(int i=0; i<intv.size(); i++)
        cout << intv[i] << "\t";


}


