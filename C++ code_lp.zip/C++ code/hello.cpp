#include<iostream>
using namespace std;
int main()
{

    cout<<"welcome to pune...";
    return 0;

}
