#include<iostream>
using namespace std;



class student
{
    int roll_no;
    int *ptr;

public:
    student()
    {
        ptr = new int;
        *ptr=0;
        roll_no=12;
        cout<<"1) Default constructor"<<"\n ";
    }

    student(int n)
    {
        ptr=new int;
        *ptr=n;
        roll_no=n;
        cout<<"2) parameterized constructor"<<"\n ";
    }

    student(student &t)
    {

        roll_no=t.roll_no;
        cout<<"3) copy constructor:-"<<"\n";
    }


    int getvalue()
    {
        return roll_no;
    }
    void setvalue(int a)
    {
        roll_no=a;
    }

   /* int getvalue()
    {
        return *ptr;
    }
    void setvalue(int b)
    {
        *ptr=b;
    }
    */


/*
    student operator +(student &x)
    {
        student temp;
        temp.setvalue(roll_no+x.getvalue());
        cout<<"\n declare operator + \n";
        return temp;

    }
    */

    student operator -(student &y)
    {
        student temp;
        temp.setvalue(*ptr+y.getvalue());
        cout<<"declare operator using pointer "<<"\n";
        return temp;
    }

~student()
       {
           cout<<"\n Destructor is called..";
       }

void display()
{
    cout<<"Roll number is :-"<<roll_no<<"\n";
    cout<<"pointer is :- "<<*ptr<<"\n";
}

};


int main()
{
    student obj1;
    obj1.display();

    student obj2(55);
    obj2.display();


    student obj3(obj2);


    obj3 = obj1 - obj2;
    //obj3.display();
obj3.display();

    return 0;


}
