
//To Demonstrate restricting exception for a function

#include<iostream>
#include<cstring>
using namespace std;

class A{
    char message[100];
public:
    A(){
        strcpy(message."A error message");
    }
    char *get_message(){
        return message;

    }
};


class B:public A{
    char message[100];
public:
    A(){
        strcpy(message."B error message");
    }
    char *get_message(){
        return message;

    }
};







cout<<"-----start------\n";
    int v;
    try{
        cout<<"enter positive value:";
    cin>>v;
    if(v<0)throw *(new NegativeException())
    cout<<"The enter value is :"<<v<<"\n";

    }catch(NegativeException *nve){
        cout <<nve.get_message();

    }
    cout<<"--------end--------";

}

/*

//Program to Demonstrate user defined Exception
#include<iostream>
using namespace std;
class StackOverFlow:exception{};
class StackUnderFlow:exception{};
class Stack
{
private:
int *stk;
int top=-1;
int size;
public:
Stack(int sz)
{
size=sz;
stk=new int[size];
}
void push(int x)
{
if(top==size-1)
throw StackOverFlow();
top++;
stk[top]=x;
}
int pop()
{
if(top==-1)
throw StackUnderFlow();
return stk[top--];
}
};
int main()
{
Stack s(5);


s.push(2);
s.push(3);
s.push(4);
s.push(10);
s.push(9);
s.push(8);
}
*/
