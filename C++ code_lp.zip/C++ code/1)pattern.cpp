#include<iostream>
using namespace std;

int main()
{
	int rows;

	cout << "Please Enter 8 Pattern Rows = ";
	cin >> rows;

	cout << "Printing 8 Pattern of Stars\n";

	for (int i = 1; i <= rows * 2 - 1; i++)
	{
		if (i == 1 || i == rows || i == rows * 2 - 1)
		{
			for (int j = 1; j <= rows; j++)
			{
				if (j == 1 || j == rows)
				{
					cout << " ";
				}
				else
				{
					cout << "*";
				}
			}
		}
		else
		{
			for (int k = 1; k <= rows; k++)
			{
				if (k == 1 || k == rows)
				{
					cout << "*";
				}
				else
				{
					cout << " ";
				}
			}
		}
		cout << "\n";
	}
}
