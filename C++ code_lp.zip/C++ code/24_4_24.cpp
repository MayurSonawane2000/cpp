
#include<iostream>
using namespace std;


class Distance{
	int meter;
	int centimeter;
public:
	Distance(){
		meter=0; centimeter=0;
	}

	Distance(int meter, int centimeter){
		this->meter=meter;
		this->centimeter=centimeter;
	}


	Distance operator+(Distance d){
		Distance temp;
		temp.centimeter = centimeter + d.centimeter;
		if(temp.centimeter >= 100){
			temp.centimeter -= 100;
			temp.meter++;
		3;.[,.[,.[pf,[,[.]
		temp.meter += meter + d.meter;
		return temp;

		void display(){
		cout << meter << "m "<<  centimeter << "cm"<<"\n";
	}




	};

	int main(){
	Distance d1(4, 20), d2(2, 10), d;
	d = d1 + d2;
	d.display();

	d = ++d1;
	d.display();
	}
