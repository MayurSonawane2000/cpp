
#include<iostream>
using namespace std;



class myarray
{
    int size;
    int *ptr;


public:
    myarray()
    {
        size=5;
        ptr=new int[size];
        for(int i=0;i<size;i++)
            ptr[i]=0;
    }
    void display()
    {
        cout<<"ptr is "<<ptr;

    }




};



int main()
{
    myarray obj1;
    obj1.display();
    return 0;

}
