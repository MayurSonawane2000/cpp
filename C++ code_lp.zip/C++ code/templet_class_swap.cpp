




#include<iostream>
using namespace std;




template<class T>

   int swap(T& a, T& b){

   T t;
   t=a;
   a=b;
   b=t;


    }








int main(){

    int a,b;
    a=10,b=20;

    swap(a,b);
   cout<<a<<" "<<b;


    return 0;

}
