#include<iostream>
using namespace std;
int main()
{
    int n,i,j
    cout<<"Enter a value :-"
}
