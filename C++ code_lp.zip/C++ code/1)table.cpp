//1)Print table of a given number


#include<iostream>
using namespace std;
int main()
{
    int n,i,j;
    cout<<"Enter a number:-";
    cin>>n;

    for (i=n;i<=n;i++)
    {
        cout<<"\n";
        for(j=1;j<=10;j++)
        {
            cout<<" "<<i*j;
        }

    }

}
