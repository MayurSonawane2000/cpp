


#include<iostream>
using namespace std;


template<class T>
//generic
void display(T a, int tab){
    for (int i=tab;i>=0;i--)
        cout<<' ';
    cout<<a <<"\n";

}




int main(){
    display("I like c++",0);
    display('A',1);
    display(100,2);
    display((float)10/3,3);

    return 0;

}
