/*

#include <iostream>
#include <map>
#include <iomanip>

using namespace std;

// Function to display the main menu
void displayMainMenu() {
    cout << "1. Breakfast\n";
    cout << "2. Lunch\n";
    cout << "3. Dinner\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";
}

// Function to display the breakfast menu
void displayBreakfastMenu() {
    cout << "Breakfast Menu\n";
    cout << "1. Sandwich - $5\n";
    cout << "2. Pancakes - $6\n";
    cout << "3. Omelette - $7\n";
    cout << "4. Back to Main Menu\n";
    cout << "Enter your choice: ";
}

// Function to display the lunch menu
void displayLunchMenu() {
    cout << "Lunch Menu\n";
    cout << "1. Burger - $8\n";
    cout << "2. Salad - $6\n";
    cout << "3. Pizza - $10\n";
    cout << "4. Back to Main Menu\n";
    cout << "Enter your choice: ";
}

// Function to display the dinner menu
void displayDinnerMenu() {
    cout << "Dinner Menu\n";
    cout << "1. Steak - $15\n";
    cout << "2. Fish - $12\n";
    cout << "3. Pasta - $9\n";
    cout << "4. Back to Main Menu\n";
    cout << "Enter your choice: ";
}

int main() {
    map<string, double> menu = {
        {"Sandwich", 5.0},
        {"Pancakes", 6.0},
        {"Omelette", 7.0},
        {"Burger", 8.0},
        {"Salad", 6.0},
        {"Pizza", 10.0},
        {"Steak", 15.0},
        {"Fish", 12.0},
        {"Pasta", 9.0}
    };

    int choice;
    double totalBill = 0.0;

    do {
        displayMainMenu();
        cin >> choice;

        switch(choice) {
            case 1: {
                displayBreakfastMenu();
                int breakfastChoice;
                cin >> breakfastChoice;
                if (breakfastChoice >= 1 && breakfastChoice <= 3) {
                    auto it = menu.begin();
                    advance(it, breakfastChoice - 1);
                    totalBill += it->second;
                }
                break;
            }
            case 2: {
                displayLunchMenu();
                int lunchChoice;
                cin >> lunchChoice;
                if (lunchChoice >= 1 && lunchChoice <= 3) {
                    auto it = menu.begin();
                    advance(it, lunchChoice + 2);
                    totalBill += it->second;
                }
                break;
            }
            case 3: {
                displayDinnerMenu();
                int dinnerChoice;
                cin >> dinnerChoice;
                if (dinnerChoice >= 1 && dinnerChoice <= 3) {
                    auto it = menu.begin();
                    advance(it, dinnerChoice + 5);
                    totalBill += it->second;
                }
                break;
            }
            case 4:
                cout << "Total bill amount: $" << fixed << setprecision(2) << totalBill << endl;
                break;
            default:
                cout << "Invalid choice. Please enter a valid option.\n";
        }
    } while (choice != 4);

    return 0;
}

*/


/*
#include <iostream>
#include <map>

using namespace std;

// Function to display the main menu
void displayMainMenu() {
    cout << "Welcome to Our Hotel!" << endl;
    cout << "1. Breakfast" << endl;
    cout << "2. Lunch" << endl;
    cout << "3. Dinner" << endl;
    cout << "4. Exit" << endl;
    cout << "Enter your choice: ";
}

// Function to display the sub-menu based on the choice
void displaySubMenu(int choice) {
    switch(choice) {
        case 1:
            cout << "Breakfast Menu:" << endl;
            cout << "1. Sandwich - $5" << endl;
            cout << "2. Pancakes - $7" << endl;
            break;
        case 2:
            cout << "Lunch Menu:" << endl;
            cout << "1. Burger - $8" << endl;
            cout << "2. Salad - $6" << endl;
            break;
        case 3:
            cout << "Dinner Menu:" << endl;
            cout << "1. Steak - $15" << endl;
            cout << "2. Pasta - $10" << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
    }
}

int main() {
    map<string, double> menu = {{"Sandwich", 5.0}, {"Pancakes", 7.0}, {"Burger", 8.0}, {"Salad", 6.0}, {"Steak", 15.0}, {"Pasta", 10.0}};
    int choice, subChoice, quantity;
    double totalBill = 0.0;
    string item;

    do {
        displayMainMenu();
        cin >> choice;

        if(choice >= 1 && choice <= 3) {
            displaySubMenu(choice);
            cout << "Enter your choice: ";
            cin >> subChoice;

            switch(subChoice) {
                case 1:
                case 2:
                case 3:
                    cout << "Enter quantity: ";
                    cin >> quantity;

                    if(subChoice == 1)
                        item = (choice == 1) ? "Sandwich" : ((choice == 2) ? "Burger" : "Steak");
                    else
                        item = (choice == 1) ? "Pancakes" : ((choice == 2) ? "Salad" : "Pasta");

                    totalBill += menu[item] * quantity;
                    break;
                default:
                    cout << "Invalid choice!" << endl;
            }
        } else if(choice != 4) {
            cout << "Invalid choice!" << endl;
        }

    } while(choice != 4);

    cout << "Total bill amount: $" << totalBill << endl;

    return 0;
}

*/


#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    // Menu items and their prices
    const int numItems = 3;
    string items[numItems] = {"1. Burger", "2. Pizza", "3. Pasta"};
    double prices[numItems] = {5.99, 8.99, 7.49};

    // Variables for user input
    int choice, quantity;
    double total = 0.0;

    do {
        // Display the menu
        cout << "Menu:" << endl;
        for (int i = 0; i < numItems; ++i) {
            cout << items[i] << " - $" << fixed << setprecision(2) << prices[i] << endl;
        }
        cout << "4. Exit" << endl;

        // Ask for user choice
        cout << "Enter your choice: ";
        cin >> choice;

        // Validate user input
        if (choice < 1 || choice > numItems + 1) {
            cout << "Invalid choice. Please try again." << endl;
            continue;
        }

        if (choice == numItems + 1) {
            // Exit the loop if the user chooses to exit
            break;
        }

        // Ask for quantity
        cout << "Enter quantity: ";
        cin >> quantity;

        // Calculate and display the total for this item
        double itemTotal = prices[choice - 1] * quantity;
        cout << "Total for " << items[choice - 1] << " x" << quantity << " = $" << fixed << setprecision(2) << itemTotal << endl;

        // Add to the overall total
        total += itemTotal;

    } while (true);

    // Display the total bill amount
    cout << "Your total bill amount is: $" << fixed << setprecision(2) << total << endl;

    return 0;
}
