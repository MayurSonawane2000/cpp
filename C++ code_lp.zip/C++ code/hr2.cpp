#include<iostream>
using namespace std;
int main()
{
    int target,i,j,n;
    while (true)
    {
        cout<<"Enter a size of array";
        cin>>n;
        if ((n>=2) && (n<=104))
            break;
            cout<<"Enter a size in range 2 to 104";
    }

    int num[i];
    for(i=0;i<n;i++)
    {

        cout<<"Enter a value:-";
        cin>>num[i];
        if(!(num[i]>=-109)  &&  (num[i]<=109))
        {

            cout<<"\n Enter range -109 to 109 ";
            i--;
        }
    }

    cout<<"Enter target:-";
    cin>>target;
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(num[i]+num[j]==target)

            {
                cout<< " [ "<< i << " , " << j << " ] " ;
                return 0;

            }
        }
    }
    cout<<"Not found";
    return 0;

}
