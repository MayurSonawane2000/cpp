#include<iostream>
using namespace  std;



void incerement_sec(int* SS,int* MM,int* HH);

class time
{
    int HH, MM, SS;

public:
    void set_hour(int H)
   {
        HH = H;
   }
   void set_min(int M)
   {
       MM = M;
   }
   void set_sec(int S)
   {
        SS = S;
   }
   void set_time(int H, int M, int S)
   {
      HH = H ; MM = M; SS = S;
   }

   void display()
   {
      cout<<"\n"<<HH<<"-"<<MM<<"-"<<SS;
   }

};
 void incerement_sec(int *SS,int *MM,int *HH)
 {

     if(*SS ==59)
     {
         if(*MM ==59)
         {
             cout<<"\n HH:"<<*HH<<"\n MM:"<<*MM<<"\n SS:"<<SS;
             if

                 (*HH==23)
                 *HH=0;

             else
             {
             *HH=*HH+1;
             MM=0;
             SS=0;
             }

         }
         else
         {
             *MM==*MM+1;
             *SS=0;
         }
     }
     else
     {
         *SS=*SS+1;
     }

 }


int main()
{
    time obj1,obj2;
    int SS,MM,HH;

    obj1.set_time(2,60,60);
    obj1.display();




  incerement_sec(&SS,&MM,&HH);

 cout << "\n HH: " << HH << " MM: " << MM << " SS: " << SS;

 obj1.display();


    return 0;
}
