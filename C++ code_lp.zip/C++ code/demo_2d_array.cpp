
#include<iostream>
using namespace std;

void accept_array(int **m);
void display_2d_array(int **a);

int main()
{
    int**mat,i ,j;
    mat=new int*[3];

    for(i=0;i<3;i++)
        mat[i]=new int[3];

    accept_array(mat);
    display_2d_array(mat);

    return 0;


}

void accept_array(int **m)
{
    int i,j;
    for (i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            cout<<"Enter a number:-";
            cin>>m[i][j];
        }
    }
}



void display_2d_array(int **a)
{

    int i,j;
    for (i=0;i<3;i++)
    {
        cout<<" \n ";
        for(j=0;j<3;j++)
        {
            if (i=j)
            int sum=i+j;

            cout<<" "<<a[i][j];
        }
    }
}










