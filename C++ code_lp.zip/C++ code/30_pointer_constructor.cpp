#include<iostream>
using namespace std;


class pointer
{

    int *ptr;

public:

        pointer()
        {
            ptr=new int;
            *ptr =45;
        }
        pointer(int n)
        {
            ptr=new int;
            *ptr = n;
        }

        void display()
        {
            cout<<"\n value is:-"<<*ptr;
        }



};

int main()
{
    pointer obj1;
    obj1.display();
    pointer obj2(15);
    obj2.display();

    return 0;
}
