
#include<iostream>
using namespace std;


class Distance{
	int meter;
	int centimeter;
public:
	Distance(){
		meter=0; centimeter=0;
	}

	Distance(int meter, int centimeter){
		this->meter=meter;
		this->centimeter=centimeter;
	}


	Distance operator+(Distance d){
		Distance temp;
		temp.centimeter = centimeter + d.centimeter;
		if(temp.centimeter >= 100){
			temp.centimeter -= 100;
			temp.meter++;
		}
		temp.meter += meter + d.meter;
		return temp;
	// 5 60 => 6 60
//	Distance operator++(){		//pre-increment  operator function
//		++this->meter;
//		return *this;
//	}
//
	Distance operator++(int x){	//post-increment  operator function
		this->meter++;
		return *this;
	}

	Distance operator=(Distance d){	//assignnment operator function
		this->meter = d.meter;
		this->centimeter = d.centimeter;
		return *this;
	}

	Distance operator+=(Distance d){	//compound assignnment  operator function
		this->meter += d.meter;
		this->centimeter += d.centimeter;
			if(this->centimeter >= 100){		//check for meter correction
			this->centimeter -= 100;			//reduce centimeter
			this->meter++;					//increment meter by 1
		}
		return *this;
	}

	void display(){
		cout << meter << "m "<<  centimeter << "cm"<<"\n";
	}

	//friend functions, as non-member operator functions
	friend Distance& operator++(Distance d);
	friend Distance& operator+(Distance d, int m);
	friend Distance& operator+(int m, Distance d);
};

//main() function
int main(){
	Distance d1(4, 20), d2(2, 10), d;
	d = d1 + d2;						// d = d1.operator+(d2);
	d.display();

	cout << "Now with friend function ....\t";
	d = ++d1;
	d.display();

	d = d2++;
	d.display();

	Distance d3 = d;
	d3.display();

	d += d1;
	d.display();

	cout << "Now with friend function ....\t";
	d = d1 + 10;
	d.display();

	d = 10 + d1;
	d.display();
}

//non-member operator function,
//for pre-increment
Distance& operator++(Distance d){
	d.meter++;
	return d;
}

//for adding constant meter to distance
Distance& operator+(Distance d, int m){
	d.meter+=m;
	return d;
}

//for adding constant meter to distance, in different way
Distance& operator+(int m, Distance d){
	d.meter+=m;
	return d;
}
