#include<iostream>
using namespace std;


void cal_ref(int &,int &,int &,int &,int &);

int main()
{

    int num1,num2,add,sub,mul;
    cout<<"\n Enter a 1st number:-";
    cin>>num1;
    cout<<"\n Enter a 2nd number:-";
    cin>>num2;
    cal_ref(num1,num2,add,sub,mul);
    cout<<"\nCalculation add,sub,mul is :-";
    cout<<"\n add="<<add<<"\n sub="<<sub<<"\n mul="<<mul;
    return 0;

}

void cal_ref(int &a,int &b,int &add,int &sub,int &mul)
{

    add=a+b;
    sub=a-b;
    mul=a*b;

}

