//Take a number from user and print it is perfect number or not :- square

#include<iostream>
using namespace std;
int main()
{
    int num1,i;

    cout<<"Enter a value search for perfect square number:-";
    cin>>num1;


    for(i=1;i*i<=num1;i++)
    {

        if((i*i)==num1)
        {
            cout<<"\n perfect square:-yes\n";
            break;
        }
    }
    if ((i*i)!=num1)
        cout<<"\n perfect square :-NO\n";



}


