#include<iostream>
using namespace  std;


class time
{
    int HH, MM, SS;

public:
    void set_hour(int H)
   {
        HH = H;
   }
   void set_min(int M)
   {
       MM = M;
   }
   void set_sec(int S)
   {
        SS = S;
   }
   void set_time(int H, int M, int S)
   {
      HH = H ; MM = M; SS = S;
   }



   void incrementsec()
   {

      SS++;
      if(SS==59)
      {
          SS=0;
          MM=M+1;
          incrementmin( HH);
      }
   }

   void incrementmin(int H)
   {
      MM++;
      if(MM==60)
      {
          MM=0;
          HH=H+1;
          incrementhour();
      }
   }

   void incrementhour()
   {
      HH++;
      if(HH>=24)
      {
          HH=0;

      }
   }





   void display()
   {
      cout<<"\n"<<HH<<"-"<<MM<<"-"<<SS;
   }
};



int main()
{
    time obj1,obj2,obj3,obj4;

    obj1.set_time(2,59,60);
    obj1.display();






    obj2.incrementsec(61);
    obj2.display();

    obj3.incrementmin(61);
    obj3.display();

    obj4.incrementhour(4);
    obj4.display();



    return 0;
}
