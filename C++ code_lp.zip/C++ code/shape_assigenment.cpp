
#include<iostream>
using namespace std;
class Shapes{
	protected:
		double area;
	public:
		Shapes()
		{
			area=0;
		}
		virtual void calculate_Area()=0;
		virtual void display()=0;
		virtual double perimeter()=0;
};
class Shape_2D:public Shapes{

public:
	virtual double perimeter()=0;
	virtual void calculate_Area()=0;
	virtual void display()=0;
};
//class Shape_3D:public Shapes{
//public:
//	virtual double volume()=0;
//	virtual void calculate_Area()=0;
//	virtual void display()=0;
//};
class Circle:public Shape_2D{
	double radius;
public:
	Circle()
	{
		radius=0;
	}
	Circle(double r)
	{
		radius=r;
	}
	void setValue(double r)
	{
		radius=r;
	}
	void calculate_Area(){
		area=3.14*radius*radius;
		}
		double perimeter()
		{
			return (2*3.14*radius);
		}
	void display()
		{
			cout<<"Area of Circle:"<<area;
		}
};
class Rectangle:public Shape_2D{
	double height;
	double width;
public:
	Rectangle()
	{
		height=0;
		width=0;
	}
	Rectangle(double h,double w)
	{
		height=h;
		width=w;
	}
//	void setValue(double )
//	{
//		hw=x;
//	}
		void calculate_Area(){
			area=height*width;
		}
		double perimeter()
		{
			return (2*(height+width));
		}
		void display()
		{
			cout<<"Area of Rectangle:"<<area;
		}
};

int main()
{
	int size=1;
	int pos=0;
	Shapes* shape[size];
	int ch;
	do{
		cout<<"\n\n**** 2D shapes***** \n";
		cout<<"\n 1.ADD Circle\n";
		cout<<"\n 2.ADD Rectangle\n";
		cout<<"\n 3.search shape\n";
//		cout<<"\n**** 3D shapes***** \n";
//		cout<<"\n 3.ADD Sphere\n";
//		cout<<"\n 4.ADD Cube\n";
		cout<<"\n 5.Display All shapes\n";
		cout<<"\nEnter your choice\n";
		cin>>ch;
		switch(ch)
		{
			case 1: double r;
				cout<<"\nEnter radius..";
				cin>>r;
				shape[pos]=new Circle(r);
				pos++;
				size++;
				break;
			case 2: double h,w;
				cout<<"\nEnter height..";
				cin>>h;
				cout<<"\nEnter width..";
				cin>>w;
				shape[pos]=new Rectangle(h,w);
				pos++;
				size++;

				break;
			case 3:
				int search;
				cout<<"\n Enter num for shape to search\n";
				cin>>search;
				search=search-1;
				shape[search]->calculate_Area();
				shape[search]->display();
				cout<<"\nPerimeter: "<<shape[search]->perimeter()<<"\n";


					break;
			case 4:
				int s;
				cout<<"\n Enter num for shape to search\n";
				cin>>s;
				s=s-1;

				shape[s]->calculate_Area();
				shape[s]->display();

				delete shape[s];
				cout<<"delete!";
				break;

			case 5:
			cout<<"\n All shapes";
				for(int i=0;i<size-1;i++)
				{
				cout<<"\n"<<i+1<<". \n";
				shape[i]->calculate_Area();
				shape[i]->display();
				cout<<"\nPerimeter: "<<shape[i]->perimeter();
			}
				break;


		}











	}while(ch!=6);

return 0;
}
