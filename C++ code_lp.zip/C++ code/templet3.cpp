



#include<iostream>
using namespace std;

const int TABWIDTH=8;


template<class T>
class myClass{
    T1 a;
    T2 b;
public:
    myClass(T1 a, const T2 b){   //constructor
        this->a=a;
        this->b=b;


    }
    void show(){
        cout<<a<<","<<b<<"\n";

    }

};





int main(){
    myClass<int,float > ob1(1,90.34f);
    myClass<char,char *> ob2('A','mayur');
    ob1.show();
    ob2.show();


    return 0;

}
