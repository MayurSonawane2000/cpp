#include <iostream>
#include <cmath>

class Shape {
public:
    virtual float area() const = 0; // Pure virtual function for area calculation
    virtual ~Shape() {} // Virtual destructor
};

class Circle : public Shape {
private:
    float radius;
public:
    Circle(float r) : radius(r) {}

    float area() const override {
        return M_PI * radius * radius;
    }
};

class Rectangle : public Shape {
private:
    float length, width;
public:
    Rectangle(float l, float w) : length(l), width(w) {}

    float area() const override {
        return length * width;
    }
};

class Triangle : public Shape {
private:
    float base, height;
public:
    Triangle(float b, float h) : base(b), height(h) {}

    float area() const override {
        return 0.5 * base * height;
    }
};

class Square : public Shape {
private:
    float side;
public:
    Square(float s) : side(s) {}

    float area() const override {
        return side * side;
    }
};

int main() {
    int choice;
    float area;

    std::cout << "Input 1 for area of circle\n";
    std::cout << "Input 2 for area of rectangle\n";
    std::cout << "Input 3 for area of triangle\n";
    std::cout << "Input 4 for area of square\n";
    std::cout << "Input your choice: ";
    std::cin >> choice;

    Shape *shape = nullptr;

    switch (choice) {
        case 1: {
            float radius;
            std::cout << "Input radius of the circle: ";
            std::cin >> radius;
            shape = new Circle(radius);
            break;
        }
        case 2: {
            float length, width;
            std::cout << "Input length and width of the rectangle: ";
            std::cin >> length >> width;
            shape = new Rectangle(length, width);
            break;
        }
        case 3: {
            float base, height;
            std::cout << "Input the base and height of the triangle: ";
            std::cin >> base >> height;
            shape = new Triangle(base, height);
            break;
        }
        case 4: {
            float side;
            std::cout << "Input the side of the square: ";
            std::cin >> side;
            shape = new Square(side);
            break;
        }
        default:
            std::cout << "Invalid choice. Please choose from the given options.\n";
            return 1;
    }

    if (shape) {
        area = shape->area();
        std::cout << "The area is: " << area << std::endl;
        delete shape;
    }

    return 0;
}
