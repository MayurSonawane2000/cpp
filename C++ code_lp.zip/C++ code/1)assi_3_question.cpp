#include <iostream>
using namespace std;

class BankAccount
{
    string name;
    int Acc_no;
    string type;
    int balance;

public:
    BankAccount()
    {
        balance =1000;
        Acc_no =123456;
        type = "Current ";
        name = "suresh ";
    }
    void deposit(int amount)
    {
        cout<<"Deposit value is:-  "<<amount<<"\n";
        this->balance = this->balance + amount;
    }
    BankAccount(int acountno, int bal, string c, string typ)
    {
        this->Acc_no = acountno;
        this->balance = bal;
        this->name = c;
        this->type = typ;
        cout<<"total Balance is :-"<<bal<<"\n";
        cout<<"holder name is :-"<<c<<"\n";
    }
    void display()
    {
        cout << this->balance << endl;
        cout << this->name << endl;
        cout << this->type << endl;
        cout << this->Acc_no <<"\n"<<endl;
    }
    void withdraw(int am)
    {
        cout<<"withdraw is:-"<<am<<"\n";
        if (this->balance > am)
            this->balance = this->balance - am;

    }
    void init(int acountno, int bal, string nam, string typ)
    {
        this->Acc_no = acountno;
        this->balance = bal;
        this->name = nam;
        this->type = typ;
    }
    ~BankAccount()
    {
        cout << "destructor is called.......";
    }
};

int main()
{

    BankAccount obj1;
    obj1.display();
    BankAccount obj2(35114854, 1500, "RAJKUMAR", "saving");
    obj2.withdraw(500);

    obj2.display();
    obj2.deposit(500);
    obj2.display();

}
