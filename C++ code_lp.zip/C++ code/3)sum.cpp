//3)Take a number from user and print sum of its digits


#include<iostream>
using namespace std;
int main()
{
    int num1,num2,sum;
    cout<<"Enter a 1 st number:-";
    cin>>num1;
    cout<<"Enter a 2 nd number :-";
    cin>>num2;

    sum=num1+num2;n
    cout<<"sum of two number is:-  "<<sum;


}
