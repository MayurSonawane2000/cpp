#include<iostream>
using namespace std;



class date
{
    int dd,mm,yy;

    public:

        void set_date(int dd,int mm,int yy)
        {
            this->dd=dd;
            this->mm=mm;
            this->yy=yy;

        }
        void display()
        {
            cout<<"\n"<<dd<<"/"<<mm<<"/"<<yy;

        }

};


int main()
{
    date obj1;
    obj1.set_date(11,11,11);
    obj1.display();

    return 0;
}
