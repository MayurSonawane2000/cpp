#include<iostream>
using namespace std;


 void swap_ref(int &,int &);

int main()
{

    int num1=74,num2=66;
    cout<<"\n num1="<<num1<<"\n num2="<<num2;
    swap_ref(num1,num2);
    cout<<"\n Swap number is:-";
    cout<<"\n num1="<<num1<<"\t num2="<<num2;
    return 0;

}
void swap_ref(int &a,int &b)
{

    int temp;
    temp = a;
    a = b;
    b = temp;
}
