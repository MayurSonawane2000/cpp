/*

#include<iostream>
using namespace std;

class Shapes {
protected:
    double area;
public:
    Shapes() {
        area = 0;
    }
    virtual void calculate_Area() = 0;
    virtual void display() = 0;
    virtual double perimeter() = 0;
};

class Shape_2D :public Shapes {
public:
    virtual double perimeter() = 0;
    virtual void calculate_Area() = 0;
    virtual void display() = 0;
};

class Circle :public Shape_2D {
    double radius;
public:
    Circle() {
        radius = 0;
    }
    Circle(double r) {
        radius = r;
    }
    void setValue(double r) {
        radius = r;
    }
    void calculate_Area() {
        area = 3.14 * radius * radius;
    }
    double perimeter() {
        return (2 * 3.14 * radius);
    }
    void display() {
        cout << "Area of Circle: " << area << endl;
    }
};

class Rectangle :public Shape_2D {
    double height;
    double width;
public:
    Rectangle() {
        height = 0;
        width = 0;
    }
    Rectangle(double h, double w) {
        height = h;
        width = w;
    }
    void calculate_Area() {
        area = height * width;
    }
    double perimeter() {
        return (2 * (height + width));
    }
    void display() {
        cout << "Area of Rectangle: " << area << endl;
    }
};

int main() {
    int size = 0;
    int ch;
    Circle* circle = nullptr;
    Rectangle* rectangle = nullptr;

    do {
        //cout << "\n\n------2D shapes-------- \n";
        cout << "\n 1.Area of Circle\n";
        cout << "\n 2.area of Rectangle\n";
        cout << "\nEnter your choice: ";
        cin >> ch;

        switch (ch) {
        case 1:
            double r;
            cout << "\nEnter radius: ";
            cin >> r;
            if (circle != nullptr)
                delete circle;
            circle = new Circle(r);
            circle->calculate_Area();
            circle->display();
            cout << "\nPerimeter: " << circle->perimeter() << "\n";
            break;

        case 2:
            double h, w;
            cout << "\nEnter height: ";
            cin >> h;
            cout << "\nEnter width: ";
            cin >> w;
            if (rectangle != nullptr)
                delete rectangle;
            rectangle = new Rectangle(h, w);
            rectangle->calculate_Area();
            rectangle->display();
            cout << "\nPerimeter: " << rectangle->perimeter() << "\n";
            break;
        }

    } while (ch != 3);

    delete circle;
    delete rectangle;

    return 0;
}

*/



#include<iostream>
using namespace std;

class Shapes {
protected:
    double area;
public:
    Shapes() {
        area = 0;
    }
    virtual void calculate_Area() = 0;
    virtual void display() = 0;
    virtual double perimeter() = 0;
};

class Shape_2D :public Shapes {
public:
    virtual double perimeter() = 0;
    virtual void calculate_Area() = 0;
    virtual void display() = 0;
};

class Circle :public Shape_2D {
    double radius;
public:
    Circle() {
        radius = 0;
    }
    Circle(double r) {
        radius = r;
    }
    void setValue(double r) {
        radius = r;
    }
    void calculate_Area() {
        area = 3.14 * radius * radius;
    }
    double perimeter() {
        return (2 * 3.14 * radius);
    }
    void display() {
        cout << "Area of Circle: " << area << endl;
    }
};

class Rectangle :public Shape_2D {
    double height;
    double width;
public:
    Rectangle() {
        height = 0;
        width = 0;
    }
    Rectangle(double h, double w) {
        height = h;
        width = w;
    }
    void calculate_Area() {
        area = height * width;
    }
    double perimeter() {
        return (2 * (height + width));
    }
    void display() {
        cout << "Area of Rectangle: " << area << endl;
    }
};

class Shape_3D :public Shapes {
public:
    virtual double volume() = 0;
    virtual void calculate_Area() = 0;
    virtual void display() = 0;
};

class Cube :public Shape_3D {
    double side;
public:
    Cube() {
        side = 0;
    }
    Cube(double s) {
        side = s;
    }
    void setValue(double s) {
        side = s;
    }
    void calculate_Area() {
        area = 6 * side * side;
    }
    double perimeter() {
        return (12 * side);
    }
    double volume() {
        return side * side * side;
    }
    void display() {
        cout << "Surface Area of Cube: " << area << endl;
        cout << "Volume of Cube: " << volume() << endl;
    }
};

class Cylinder :public Shape_3D {
    double radius;
    double height;
public:
    Cylinder() {
        radius = 0;
        height = 0;
    }
    Cylinder(double r, double h) {
        radius = r;
        height = h;
    }
    void setValue(double r, double h) {
        radius = r;
        height = h;
    }
    void calculate_Area() {
        area = 2 * 3.14 * radius * (radius + height);
    }
    double perimeter() {
        return (2 * 3.14 * radius);
    }
    double volume() {
        return 3.14 * radius * radius * height;
    }
    void display() {
        cout << "Surface Area of Cylinder: " << area << endl;
        cout << "Volume of Cylinder: " << volume() << endl;
    }
};

int main() {
    int size = 0;
    int ch;
    Circle* circle = nullptr;
    Rectangle* rectangle = nullptr;
    Cube* cube = nullptr;
    Cylinder* cylinder = nullptr;

    do {
        cout << "\n\n------ Shapes Menu --------- \n";
        cout << "\n 1. Volume of Circle\n";
        cout << "\n 2. Volume of Rectangle\n";
        cout << "\n 3. Volume of  Cube\n";
        cout << "\n 4. Volume of  Cylinder\n";
        cout << "\n 5. Exit\n";
        cout << "\nEnter your choice: ";
        cin >> ch;

        switch (ch) {
        case 1:
            double r;
            cout << "\nEnter radius: ";
            cin >> r;
            if (circle != nullptr)
                delete circle;
            circle = new Circle(r);
            circle->calculate_Area();
            circle->display();
            cout << "\nPerimeter: " << circle->perimeter() << "\n";
            break;

        case 2:
            double h, w;
            cout << "\nEnter height: ";
            cin >> h;
            cout << "\nEnter width: ";
            cin >> w;
            if (rectangle != nullptr)
                delete rectangle;
            rectangle = new Rectangle(h, w);
            rectangle->calculate_Area();
            rectangle->display();
            cout << "\nPerimeter: " << rectangle->perimeter() << "\n";
            break;

        case 3:
            double s;
            cout << "\nEnter side length: ";
            cin >> s;
            if (cube != nullptr)
                delete cube;
            cube = new Cube(s);
            cube->calculate_Area();
            cube->display();
            cout << "\nPerimeter: " << cube->perimeter() << "\n";
            break;

        case 4:
            double r_cyl, h_cyl;
            cout << "\nEnter radius of base: ";
            cin >> r_cyl;
            cout << "\nEnter height of cylinder: ";
            cin >> h_cyl;
            if (cylinder != nullptr)
                delete cylinder;
            cylinder = new Cylinder(r_cyl, h_cyl);
            cylinder->calculate_Area();
            cylinder->display();
            cout << "\nPerimeter: " << cylinder->perimeter() << "\n";
            break;
        }

    } while (ch != 5);

    delete circle;
    delete rectangle;
    delete cube;
    delete cylinder;

    return 0;
}
