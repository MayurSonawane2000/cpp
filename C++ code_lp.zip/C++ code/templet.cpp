#include<iostream>
using namespace std;


template<class T>
void swapargs(T &a, T &b){
        cout<<"Now generic specialization function is called  \n";


    T temp = a;
    a = b;
    b = temp;

}

//explicit specialization
template<>
void swapargs<int>(int &a, int &b){
    cout<<"Now Explicite specialization function is called  \n";

    int temp = a;
    a = b;
    b = temp;

}



int main(){
    //int
    int x=10,y=20;
    swapargs(x,y);
    cout <<"x="<<x <<"y="<<y<< "\n\n";


    //float
    float xf=1.4,yf=2.0;
    swapargs(xf,yf);
    cout <<"xf="<<xf <<"yf="<<yf<< "\n\n";


    //double
    double xd=10,yd=20;
    swapargs(xd,yd);
    cout <<"xd="<<xd <<"yd="<<yd<< "\n\n";


    //char
    char xc='A',yc='B';
    swapargs(xc,yc);
    cout <<"xc="<<xc <<"yc="<<yc<< "\n\n";



    return 0;

}
