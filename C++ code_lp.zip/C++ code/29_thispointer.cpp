#include<iostream>
using namespace std;


class time
{
    int hh,mm,ss;

public:
    void set_time(int hh,int mm,int ss)
    {
        this->hh==hh;
        this->mm==mm;
        this->ss==ss;
    }

    void display()
    {
        cout<<"\n"<<hh<<"-"<<mm<<"-"<<ss;
    }
};

int main()
{

    time obj1;
    obj1.set_time(10,20,30);
    obj1.display();

    return 0;

}
