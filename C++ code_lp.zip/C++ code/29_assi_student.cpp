#include<iostream>
using namespace std;




class student
{
   int rno,r;
   string name,n;
   int mk1,mk2,mk3,marks1,marks2,marks3;
   float total;
   char grade;
bn



public:

    student()
    {
        rno=0;
        name="";
        mk1=0;
        mk2=0;
        mk3=0;
        total=0;
        grade=' ';



    }


    student(int rno,string name,int mk1,int mk2,int mk3)
    {



        r=rno;
        n=name;
        marks1=mk1;
        marks2=mk2;
        marks3=mk3;


    }

    void display()
    {



        cout<<"rno:- "<<r<<"\n";
        cout<<"name:- "<<n<<"\n";
        cout<<"mk1:- "<<marks1<<"\n"<<"mk2:- "<<marks2<<"\n"<<"mk3:- "<<marks3<<"\n";
        cout<<"Total marks is:-"<<total<<"\n";
        cout<<"grade is:-" <<grade<<"\n";


    }

    int getrnumber()
     {
        return r;
    }

    void setrnumber(int rno)
    {
        r = rno;
    }

    string getname()
    {
        return n;

    }
    void setname(string name)
    {
        n=name;

    }

    int getmarks1()
    {
        return marks1;
    }
    void setmarks1(int mk1)
    {
        marks1=mk1;
    }

    int getmarks2()
    {
        return marks2;
    }
    void setmarks2(int mk2)
    {
        marks2=mk2;
    }


    int getmarks3()
    {
        return marks3;
    }
    void setmarks3(int mk3)
    {
        marks3=mk3;
    }

    void calculate_grade()
    {
    total = (marks1 + marks2 + marks3)/3.0;


    if(total>=80)
    {
        grade = 'A';
    }
    else
        grade = 'F';
    }




} ;



int main()
{

    student obj1(4,"xya",10,21,31);
    obj1.calculate_grade();
    obj1.display();

    return 0;

}
