
/*#include<iostream>
using namespace std;
int main()
{
    int arr[6]={1,2,3,4,5,6};

        cout<<"The 1D array elements are:- ";
        for (int i=0;i<6;i++)
        {
            cout<<arr[i]<<" ";
        }

}
*/

#define SIZE 10
#include<iostream>
using namespace std;


void accept_array_elements(int *);
void display_array(int *);
void left_shift(int *);

int main()
{
    int ch, pos, key,i;
    int arr[SIZE];
    void accept_array_elements(int *);
    void display_array(int *);
    void left_shift(int *);

}




    void accept_array_elements(int *a)


    int i;
    for(i=0;i<SIZE;i++)
    {
        cout<<"\n Enter a number :";
        cin>>a[i];
    }



void display_array(int *arr)
{
    int i;
    cout<<"\n\n Array elements : ";
    for(i = 0; i < SIZE ; i++)
        cout<<"  "<<arr[i];

    cout<<"\n\n";
}

}










