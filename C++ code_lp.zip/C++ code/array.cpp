#include<iostream>
using namespace std;
int main()
{






//void display_array(int *arr)
    int i ,SIZE,a[i];
    for (i=0;i<SIZE;i++)
    {
        cout<<"\n Enter a element:- ";
        cin>>a[i];
    }

return 0;

}
