
#include<iostream>
#include<vector>
using namespace std;


int main(){
    //create an integer vector
    vector<char> cv;



    cv.push_back('A');
     cv.push_back('B');
      cv.push_back('C');
       cv.push_back('D');
        cv.push_back('E');
         cv.push_back('f');

         cout<<"\n Now display the vector element using itterator";




    vector<char>::iterator itr =cv.begin();

    cout << "Now displaying the vector elements...\n";

    while(itr != cv.end()){

        cout << *itr << "\n";
        itr++;
    }

    itr = cv.begin();
    itr+=3;
    //cv.insert(itr, '+');
    cv.insert(itr,4,'+');





    cout<<"Displaying vector content after inserting an element...\n";
    itr = cv.begin();
     while(itr != cv.end()){

        cout << *itr << "\n";
        itr++;
    }


    //remove elemant
    itr-=4;
    cv.erase(itr,itr+1);




}


