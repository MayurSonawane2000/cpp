//2)Take a number from user and print it is prime or not


#include<iostream>
using namespace std;
int main()
{
    int n,i,y=0,flag=0;
    cout<<"Enter a number:-";
    cin>>n;
    y=n/2;
     for(i=2;i<=y;i++)
     {

         if(n%i==0)
         {
             cout<<"no";
             flag=1;
             break;
         }
     }
     if (flag==0)
        cout<<"yes";
     return 0;

}
